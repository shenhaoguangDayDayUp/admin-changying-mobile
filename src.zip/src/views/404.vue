<template>
    <p class="page-container">404 page not found</p>
</template>
