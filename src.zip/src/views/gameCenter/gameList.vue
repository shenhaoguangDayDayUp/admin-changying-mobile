<template>
    <section>游戏列表</section>
</template>
