<template>
    <section>游戏详情</section>
</template>
