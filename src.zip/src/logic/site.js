// import $config from '$config';

// var siteName = $config.name;

// export var pageTitle = (routerTitle) => {
//     if (routerTitle) {
//         return routerTitle + ' - ' + siteName;
//     } else {
//         return siteName;
//     }
// }